/* modals.jsx — PriceEditorSheet · PaymentPanel · ReceiptModal
              · VariantSheet · TransactionSheet · EditProductModal · ContextDrawer */

/* ─── shared helpers ─── */
function loadScript(src) {
  return new Promise((res, rej) => {
    if (document.querySelector(`script[src="${src}"]`)) { res(); return; }
    const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej;
    document.head.appendChild(s);
  });
}

/* ─── Faux QR for QRIS preview ─── */
function QRCode({ size = 130 }) {
  const N = 25; let s = 7654321;
  const rnd = () => { s = (s * 1103515245 + 12345) >>> 0; return (s >>> 16) / 65536; };
  const cells = [];
  const finder = (r, c) => (r < 7 && c < 7) || (r < 7 && c >= N - 7) || (r >= N - 7 && c < 7);
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    if (finder(r, c)) continue;
    if (rnd() > 0.52) cells.push(<rect key={r+'-'+c} x={c} y={r} width="1" height="1" />);
  }
  const Eye = ({ x, y }) => (
    <g><rect x={x} y={y} width="7" height="7" rx="1.2" fill="none" stroke="#111" strokeWidth="1" />
    <rect x={x+2} y={y+2} width="3" height="3" rx=".5" fill="#111" /></g>
  );
  return (
    <svg width={size} height={size} viewBox="0 0 25 25" shapeRendering="crispEdges"
      style={{ background: '#fff', borderRadius: 10, padding: 8, boxShadow: '0 2px 10px rgba(0,0,0,.12)' }}>
      <g fill="#111">{cells}</g>
      <Eye x={0} y={0} /><Eye x={18} y={0} /><Eye x={0} y={18} />
    </svg>
  );
}

/* ─── Price editor (tap item price in cart) ─── */
function PriceEditorSheet({ item, altPrices, currentPrice, onSetPrice, onClose }) {
  const [val, setVal] = React.useState(String(currentPrice || item.price));
  const active = +val;
  return (
    <div className="sheet-scrim" onClick={onClose}>
      <div className="sheet" style={{ maxHeight: '72%' }} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-grip" />
        <div className="sheet-head">
          <div className="sheet-title"><b>Ubah Harga</b></div>
          <button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>
        <div style={{ padding: '12px 16px 8px' }}>
          <div className="field-label" style={{ fontSize: 11.5 }}>{item.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink-3)', flexShrink: 0 }}>Rp</span>
            <input className="tinput" type="number" value={val} autoFocus
              onChange={(e) => setVal(e.target.value)} onFocus={(e) => e.target.select()}
              style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--serif)', height: 52 }} />
          </div>
          {altPrices && altPrices.length > 0 && (
            <div style={{ marginTop: 14 }}>
              <div className="field-label">Harga lain yang tersedia</div>
              <div className="alt-price-chips">
                {altPrices.map((ap, i) => (
                  <button key={i} className={'alt-price-chip' + (active === ap.price ? ' active' : '')}
                    onClick={() => setVal(String(ap.price))}>
                    {ap.label} — {rp(ap.price)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="pay-foot" style={{ padding: '10px 16px 14px', borderTop: '1px solid var(--line)' }}>
          <button className="btn grow" onClick={onClose}>Batal</button>
          <button className="btn primary grow" onClick={() => { onSetPrice(Math.max(0, +val)); onClose(); }}>
            Terapkan {rp(Math.max(0, +val))}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Receipt (thermal print preview) ─── */
function ReceiptContent({ tx, store }) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })
    + ' ' + now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  const items = Array.isArray(tx.items) ? tx.items : [];
  const payments = Array.isArray(tx.payments) ? tx.payments : [];
  const lastPay = payments[payments.length - 1] || {};

  return (
    <div className="rp-paper">
      <div className="rp-header">
        <div className="rp-store">{store.name}</div>
        {store.address && <div className="rp-info">{store.address}</div>}
        {store.phone && <div className="rp-info">WA: {store.phone}</div>}
        {store.telegram && <div className="rp-info">Telegram: {store.telegram}</div>}
      </div>
      <hr className="rp-dash" />
      <div className="rp-meta">
        <span>{dateStr}</span>
        <div className="rp-meta-right">
          <div>#{tx.id?.toUpperCase()}</div>
          <div>Nomer:{payments.length || 1}</div>
        </div>
      </div>
      <div className="rp-customer">{tx.customer || 'Pelanggan'}</div>
      <hr className="rp-dash" />
      {items.map((it, i) => (
        <div key={i}>
          <div className="rp-item-name">{it.name}</div>
          <div className="rp-item-row">
            <span>{it.qty} {it.unit} x {fmt(it.price)}</span>
            <span>{fmt(it.qty * it.price)}</span>
          </div>
          {it.note && <div className="rp-item-note">* {it.note}</div>}
        </div>
      ))}
      <hr className="rp-dash" />
      <div className="rp-count">Produk: {items.length}</div>
      <hr className="rp-dash" />
      {tx.discount > 0 && (
        <div className="rp-pay-row"><span>Diskon</span><span>- {fmt(tx.discount)}</span></div>
      )}
      <div className="rp-total-row">
        <span>Total</span>
        <span>Rp {fmt(tx.total)}</span>
      </div>
      {payments.map((p, i) => (
        <div key={i}>
          <div className="rp-pay-row">
            <span>Bayar..</span>
            <span>Rp {fmt(p.paid)}</span>
          </div>
          {p.kembalian > 0 && (
            <div className="rp-kembali-row">
              <span>Kembali</span>
              <span>Rp {fmt(p.kembalian)}</span>
            </div>
          )}
          {p.hutang > 0 && (
            <div className="rp-hutang">
              <span>Hutang</span>
              <span>Rp {fmt(p.hutang)}</span>
            </div>
          )}
        </div>
      ))}
      <div className="rp-sudah">
        {tx.status === 'lunas' ? 'Sudah bayar' : `Sisa hutang Rp ${fmt(tx.remaining || 0)}`}
      </div>
      {tx.note && (
        <div className="rp-note">{tx.note}</div>
      )}
      <hr className="rp-dash" />
      <div className="rp-footer">{store.receiptNote || 'Terima kasih!'}</div>
    </div>
  );
}

function ReceiptModal({ tx, onClose }) {
  const store = (window.POS?.getConfig() || window.POS?.DEFAULT_CONFIG || {}).store || {};
  const [previewUrl, setPreviewUrl] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const receiptRef = React.useRef(null);

  React.useEffect(() => {
    let cleanup;
    (async () => {
      try {
        await loadScript('https://html2canvas.hertzen.com/dist/html2canvas.min.js');
        await new Promise(r => setTimeout(r, 120)); // let fonts settle
        const canvas = await window.html2canvas(receiptRef.current, {
          backgroundColor: '#ffffff', scale: 3, useCORS: true, logging: false,
        });
        const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.95));
        const url = URL.createObjectURL(blob);
        setPreviewUrl(url);
        setLoading(false);
        // auto-cleanup after 5 minutes
        cleanup = setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
      } catch (err) { setLoading(false); }
    })();
    return () => { if (cleanup) clearTimeout(cleanup); };
  }, []);

  const share = async () => {
    if (!previewUrl) return;
    try {
      const blob = await fetch(previewUrl).then(r => r.blob());
      const file = new File([blob], `struk_${tx.id}.jpg`, { type: 'image/jpeg' });
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: `Struk #${tx.id}` });
      } else {
        const a = document.createElement('a'); a.href = previewUrl; a.download = `struk_${tx.id}.jpg`; a.click();
      }
    } catch (e) { if (e.name !== 'AbortError') console.warn(e); }
  };

  const print = () => {
    const w = window.open('', '_blank', 'width=400,height=700');
    const html = `<!DOCTYPE html><html><head><style>
      body{margin:0;background:#f0ede8;display:flex;justify-content:center;padding:20px}
      @page{size:80mm auto;margin:4mm}
      .rp-paper{background:#fff;width:280px;padding:16px 14px 20px;font-family:'Courier New',monospace;font-size:12px;color:#111;line-height:1.4}
      .rp-store{text-align:center;font-size:16px;font-weight:900;text-transform:uppercase}
      .rp-header,.rp-info{text-align:center;font-size:11.5px;margin-top:2px}
      .rp-dash{border:none;border-top:1px dashed #777;margin:7px 0}
      .rp-meta{display:flex;justify-content:space-between;font-size:12px}
      .rp-meta-right{text-align:right}
      .rp-customer{font-size:18px;font-weight:900;margin:4px 0 8px}
      .rp-item-name{font-weight:700;font-size:13px}
      .rp-item-row{display:flex;justify-content:space-between;padding-left:4px;font-size:12px}
      .rp-item-note{padding-left:4px;font-size:11px;color:#555;font-style:italic}
      .rp-count{font-size:12px;margin:3px 0}
      .rp-total-row{display:flex;justify-content:space-between;font-weight:900;font-size:14px;margin-top:3px}
      .rp-pay-row{display:flex;justify-content:space-between;font-size:12.5px}
      .rp-kembali-row{display:flex;justify-content:space-between;font-weight:900;font-size:14px}
      .rp-hutang{display:flex;justify-content:space-between;font-size:12.5px}
      .rp-sudah{text-align:right;font-size:12px}
      .rp-note{margin-top:9px;font-size:11.5px;text-align:center;border-top:1px dashed #aaa;padding-top:7px}
      .rp-footer{text-align:center;font-size:11.5px;margin-top:10px;color:#555}
    </style></head><body>
    ${receiptRef.current?.outerHTML || ''}
    <script>window.onload=()=>{window.print();}</script></body></html>`;
    w.document.write(html); w.document.close();
  };

  return (
    <div className="receipt-scrim" onPointerDown={onClose}>
      <div className="receipt-modal" onPointerDown={(e) => e.stopPropagation()}>
        <div className="sheet-grip" />
        <div className="sheet-head" style={{ borderBottom: '1px solid var(--line)' }}>
          <div className="sheet-title"><b>Struk Pembayaran</b></div>
          <button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>

        {/* Hidden template for html2canvas capture */}
        <div style={{ position: 'absolute', left: -9999, top: 0, pointerEvents: 'none' }}>
          <div ref={receiptRef}><ReceiptContent tx={tx} store={store} /></div>
        </div>

        {/* Preview area */}
        <div className="receipt-preview-wrap">
          {loading ? (
            <div style={{ padding: '60px 20px', textAlign: 'center', color: 'var(--ink-3)', fontSize: 13 }}>
              <div style={{ marginBottom: 10 }}>Menyiapkan struk…</div>
              <div style={{ width: 24, height: 24, border: '3px solid var(--line-2)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto' }} />
            </div>
          ) : previewUrl ? (
            <img className="receipt-preview-img" src={previewUrl} alt="Struk" />
          ) : (
            /* Fallback: show HTML receipt if html2canvas fails */
            <div style={{ background: '#fff', borderRadius: 4, boxShadow: '0 4px 20px rgba(0,0,0,.2)' }}>
              <ReceiptContent tx={tx} store={store} />
            </div>
          )}
        </div>

        <div style={{ padding: '12px 16px 16px', borderTop: '1px solid var(--line)', display: 'flex', gap: 8 }}>
          <button className="btn grow" onClick={print}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6v-8Z"/></svg>
            Cetak
          </button>
          <button className="btn primary grow" onClick={share} disabled={!previewUrl && !true}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/></svg>
            Bagikan
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Simplified Payment Panel (Tunai / Non-Tunai, just keypad) ─── */
function PaymentPanel({ total: initialTotal, onClose, onDone }) {
  const [editTotal, setEditTotal] = React.useState(initialTotal);
  const [isTunai, setIsTunai] = React.useState(true);
  const [ntMenuOpen, setNtMenu] = React.useState(false);
  const [ntMethod, setNtMethod] = React.useState(null);
  const [tendered, setTendered] = React.useState(0);
  const [payNote, setPayNote] = React.useState('');
  const [stage, setStage] = React.useState('input'); // input | success
  const [lastPayment, setLastPayment] = React.useState(null);

  const payTotal = Math.max(0, editTotal || 0);
  const kembalian = isTunai ? Math.max(0, tendered - payTotal) : 0;
  const hutang    = isTunai ? (tendered > 0 && tendered < payTotal ? payTotal - tendered : 0) : 0;
  const lunas     = isTunai ? tendered >= payTotal : !!ntMethod;
  const label     = kembalian > 0 ? 'kembalian' : hutang > 0 ? 'hutang' : tendered === payTotal && tendered > 0 ? 'pas' : '';

  /* non-tunai methods from config */
  const allMethods = (window.POS?.getConfig().paymentMethods || []);
  const ntMethods  = allMethods.filter(m => m.type !== 'tunai');

  const denoms = [10000, 20000, 50000, 100000, 200000, 500000];
  const quick  = [payTotal, ...denoms.filter(d => d >= payTotal)].slice(0, 6);

  const press = (d) => {
    if (d === 'C') return setTendered(0);
    if (d === '⌫') return setTendered(t => Math.floor(t / 10));
    setTendered(t => Math.min(t * 10 + d, 99_999_999));
  };

  const confirm = () => {
    const pay = {
      ts: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      method: isTunai ? 'Tunai' : ntMethod?.name || 'Non-Tunai',
      paid:   isTunai ? tendered : payTotal,
      kembalian, hutang,
      note:   payNote,
    };
    setLastPayment(pay);
    setStage('success');
  };

  if (stage === 'success' && lastPayment) {
    return (
      <div className="pay-scrim">
        <div className="pay-panel" onClick={(e) => e.stopPropagation()}>
          <div className="sheet-grip" />
          <div className="pay-body" style={{ padding: '20px 18px 8px' }}>
            <div className="success">
              <div className="check"><Icon name="check" size={36} /></div>
              <div className="st">{lastPayment.kembalian > 0 ? 'Kembalian' : lastPayment.hutang > 0 ? 'Tercatat Hutang' : 'Pembayaran Berhasil'}</div>
              {lastPayment.kembalian > 0 && <div className="schange">{rp(lastPayment.kembalian)}</div>}
              {lastPayment.hutang > 0 && (
                <div className="schange" style={{ color: 'var(--warn)' }}>{rp(lastPayment.hutang)}</div>
              )}
              {!lastPayment.kembalian && !lastPayment.hutang && <div className="schange">{rp(payTotal)}</div>}
              <div className="ssub">via {lastPayment.method}</div>
            </div>
          </div>
          <div className="pay-foot">
            <button className="btn grow"><Icon name="receipt" size={14} /> Struk</button>
            <button className="btn primary grow" onClick={() => onDone(lastPayment)}>Selesai &amp; Baru</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pay-scrim" onPointerDown={onClose}>
      <div className="pay-panel" onPointerDown={(e) => e.stopPropagation()}>
        <div className="sheet-grip" />
        <div className="pay-head">
          <div><div className="pt">Pembayaran</div><div className="ps">Ketuk nominal untuk ubah total</div></div>
          <button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>
        <div className="pay-body">
          {/* editable total */}
          <div className="pay-total-edit">
            <span className="pte-label">Total</span>
            <span className="pte-cur">Rp</span>
            <input type="number" value={editTotal} onFocus={(e) => e.target.select()}
              onChange={(e) => setEditTotal(+e.target.value)} />
          </div>
          <div className="pay-edit-note">Ketuk nominal untuk diskon manual / pembulatan</div>

          {/* Tunai / Non-Tunai toggle */}
          <div className="pay-type-toggle" style={{ marginBottom: 12 }}>
            <button className={'pt-btn' + (isTunai ? ' on' : '')} onClick={() => setIsTunai(true)}>
              💵 Tunai
            </button>
            <button className={'pt-btn' + (!isTunai ? ' on' : '')} onClick={() => { setIsTunai(false); setTendered(0); }}>
              📲 Non-Tunai
            </button>
          </div>

          {/* Tunai section */}
          {isTunai && (
            <>
              <div className="cash-display">
                <div className="cd-row"><span>Total</span><span className="v">{rp(payTotal)}</span></div>
                <div className="cd-row"><span>Diterima</span><span className="v">{rp(tendered)}</span></div>
              </div>
              {tendered > 0 && (
                <div className={'pay-indicator ' + (kembalian > 0 ? 'kembalian' : hutang > 0 ? 'hutang' : 'pas')}>
                  <span>{kembalian > 0 ? 'Kembalian' : hutang > 0 ? 'Sisa / Hutang' : '✓ Uang Pas'}</span>
                  {(kembalian > 0 || hutang > 0) && <span className="piv">{rp(kembalian || hutang)}</span>}
                </div>
              )}
              <div className="quick-cash" style={{ marginBottom: 10 }}>
                {quick.map((d, i) => (
                  <button key={i} className={'qc' + (d === payTotal ? ' exact' : '')}
                    onClick={() => setTendered(d)}>
                    {d === payTotal ? 'Uang Pas' : fmt(d)}
                  </button>
                ))}
              </div>
              <div className="keypad">
                {[1,2,3,4,5,6,7,8,9].map(n => <button key={n} onClick={() => press(n)}>{n}</button>)}
                <button onClick={() => press('C')}>C</button>
                <button onClick={() => press(0)}>0</button>
                <button onClick={() => press('⌫')}>⌫</button>
              </div>
            </>
          )}

          {/* Non-Tunai section */}
          {!isTunai && (
            <div className="nontunai-picker">
              <button className={'nontunai-sel' + (ntMenuOpen ? ' open' : '')} onClick={() => setNtMenu(v => !v)}>
                <span className="ns-label">{ntMethod ? ntMethod.name : 'Pilih metode pembayaran'}</span>
                {ntMethod?.data && <span className="ns-data">{ntMethod.data}</span>}
                <Icon name="chevdown" size={14} stroke sw={2} style={{ flexShrink: 0 }} />
              </button>
              {ntMenuOpen && (
                <>
                  <div style={{ position: 'fixed', inset: 0, zIndex: 29 }} onClick={() => setNtMenu(false)} />
                  <div className="nontunai-drop" style={{ zIndex: 30 }}>
                    {ntMethods.length === 0 && (
                      <div style={{ padding: '14px 16px', fontSize: 13, color: 'var(--ink-3)' }}>
                        Belum ada metode non-tunai. Tambahkan di Pengaturan.
                      </div>
                    )}
                    {ntMethods.map(m => (
                      <div key={m.id} className={'ntd-item' + (ntMethod?.id === m.id ? ' selected' : '')}
                        onClick={() => { setNtMethod(m); setNtMenu(false); }}>
                        <div className="nt-name">{m.name}</div>
                        {m.data && <div className="nt-data">{m.data}</div>}
                        {m.type === 'qris' && <div className="nt-data">QRIS</div>}
                      </div>
                    ))}
                  </div>
                </>
              )}
              {/* Show QRIS or bank info when method selected */}
              {ntMethod && (
                <div className="method-meta" style={{ marginTop: 10 }}>
                  {ntMethod.type === 'qris' ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
                      <QRCode size={120} />
                      <div style={{ textAlign: 'center' }}>
                        <div style={{ fontFamily: 'var(--serif)', fontSize: 22, fontWeight: 600 }}>{rp(payTotal)}</div>
                        <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 3 }}>GoPay · OVO · DANA · ShopeePay</div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="mm-title">{ntMethod.type === 'bank' ? 'Transfer Bank' : 'E-Wallet'}</div>
                      <div className="mm-data">{ntMethod.name}{ntMethod.data ? ' — ' + ntMethod.data : ''}</div>
                      <div className="mm-sub">{rp(payTotal)}</div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Payment note */}
          <div className="pay-note-field">
            <Icon name="note" size={14} style={{ color: 'var(--ink-3)', flexShrink: 0 }} />
            <input placeholder="Catatan pembayaran (opsional)…" value={payNote}
              onChange={(e) => setPayNote(e.target.value)} />
          </div>
        </div>

        <div className="pay-foot">
          <button className="btn grow" onClick={onClose}>Batal</button>
          <button className="btn primary grow" disabled={isTunai ? tendered === 0 : !ntMethod}
            onClick={confirm}>
            {isTunai && kembalian > 0 ? `Kembali ${rp(kembalian)}` :
             isTunai && hutang > 0    ? `Catat Hutang ${rp(hutang)}` :
             isTunai && lunas         ? 'Konfirmasi Bayar' :
             !isTunai && ntMethod     ? `Proses via ${ntMethod.name}` : 'Pilih metode'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Variant / unit picker ─── */
function VariantSheet({ product, cart, onInc, onDec, onClose }) {
  return (
    <div className="sheet-scrim" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()} style={{ maxHeight: '80%' }}>
        <div className="sheet-grip" />
        <div className="var-sheet-head">
          <div className="vs-name">{product.name}</div>
          <div className="vs-sub">Pilih satuan atau variasi</div>
        </div>
        <div className="var-body">
          {(product.variants || []).map((v) => {
            const key = product.id + ':' + v.id;
            const qty = cart[key] || 0;
            const out = v.stock === 0;
            return (
              <div className={'v-opt' + (qty > 0 ? ' has' : '')} key={v.id}>
                <div className="vo-info">
                  <div className="vo-label">{v.label}</div>
                  <div className="vo-bc">
                    <span style={{ color: out ? 'var(--warn)' : 'var(--ink-3)' }}>
                      {out ? 'Habis' : 'Stok ' + v.stock}
                    </span> · {v.barcode}
                  </div>
                </div>
                <div className="vo-right">
                  <span className="vo-price">{rp(v.price)}</span>
                  {qty > 0 ? (
                    <div className="qty-group" style={{ height: 32 }}>
                      <button onClick={() => onDec(key)}><Icon name="minus" size={14} /></button>
                      <span className="n">{qty}</span>
                      <button onClick={() => onInc(key)}><Icon name="plus" size={14} /></button>
                    </div>
                  ) : (
                    <button className="add-btn" disabled={out} onClick={() => onInc(key)}>
                      <Icon name="plus" size={13} /> Pilih
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ padding: '8px 14px 14px', borderTop: '1px solid var(--line)' }}>
          <button className="pay-btn" onClick={onClose} style={{ justifyContent: 'center' }}>Selesai Pilih</button>
        </div>
      </div>
    </div>
  );
}

/* ─── Transaction history sheet ─── */
function TransactionSheet({ history: initialHistory, onClose, onAddTo, onLunasi }) {
  const [history, setHistory] = React.useState(initialHistory);
  const [query, setQuery] = React.useState('');
  const [filter, setFilter] = React.useState('semua');
  const [expanded, setExpanded] = React.useState({});
  const toggle = (id) => setExpanded(e => ({ ...e, [id]: !e[id] }));

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return history.filter(tx => {
      if (filter === 'lunas'  && tx.status !== 'lunas')       return false;
      if (filter === 'hutang' && tx.status !== 'belum_lunas') return false;
      if (!q) return true;
      if (tx.customer.toLowerCase().includes(q)) return true;
      return (tx.items || []).some(i => i.name.toLowerCase().includes(q));
    });
  }, [history, query, filter]);

  const handleLunasi = (tx) => {
    setHistory(h => h.map(t => t.id === tx.id
      ? { ...t, paid: t.total, remaining: 0, status: 'lunas' } : t));
    onLunasi && onLunasi(tx);
  };

  return (
    <div className="sheet-scrim" onClick={onClose}>
      <div className="sheet" style={{ maxHeight: '95%' }} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-grip" />
        <div className="sheet-head">
          <div className="sheet-title"><b>Riwayat Transaksi</b></div>
          <button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>
        <div className="tx-search">
          <div className="search" style={{ flex: 1 }}>
            <Icon name="search" size={15} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari pelanggan atau produk…" />
          </div>
        </div>
        <div className="tx-filters">
          {[['semua','Semua'],['lunas','Lunas'],['hutang','Belum Lunas']].map(([id, lbl]) => (
            <button key={id} className={'txf' + (filter === id ? ' on' : '')} onClick={() => setFilter(id)}>{lbl}</button>
          ))}
          <span style={{ flex: 1 }} /><span style={{ fontSize: 11, color: 'var(--ink-3)', alignSelf: 'center' }}>{filtered.length} transaksi</span>
        </div>
        <div className="tx-list">
          {filtered.map(tx => {
            const open = !!expanded[tx.id];
            const isHutang = tx.status === 'belum_lunas';
            return (
              <div className="tx-row" key={tx.id}>
                <div className="tx-row-head" onClick={() => toggle(tx.id)}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      <span className="tx-id">#{tx.id?.toUpperCase()}</span>
                      <span className="tx-cust">{tx.customer}</span>
                    </div>
                    <div className="tx-meta">{(tx.items||[]).length} item · {tx.time}{tx.note ? ' · ' + tx.note : ''}</div>
                  </div>
                  <div className="tx-right">
                    <div className="tx-total">{rp(tx.total)}</div>
                    <span className={isHutang ? 'status-hutang' : 'status-lunas'}>{isHutang ? 'Belum Lunas' : 'Lunas'}</span>
                  </div>
                  <Icon name="chevdown" size={15} stroke sw={2}
                    style={{ color: 'var(--ink-3)', transition: 'transform .18s', transform: open ? 'rotate(180deg)' : 'none', flexShrink: 0 }} />
                </div>
                {open && (
                  <div className="tx-detail">
                    {(tx.items||[]).map((it, i) => (
                      <div className="tx-detail-item" key={i}>
                        <span className="n">{it.qty}× {it.name}{it.ts ? ' · ' + it.ts : ''}</span>
                        <span className="v">{rp(it.price * it.qty)}</span>
                      </div>
                    ))}
                    {tx.discount > 0 && (
                      <div className="tx-detail-item" style={{ color: 'var(--ok)' }}>
                        <span className="n">Diskon</span><span className="v">− {rp(tx.discount)}</span>
                      </div>
                    )}
                    {/* Payment records */}
                    {(tx.payments||[]).length > 0 && (
                      <div style={{ borderTop: '1px dashed var(--line-2)', marginTop: 6, paddingTop: 6 }}>
                        <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: 5 }}>Detil Pembayaran</div>
                        {tx.payments.map((p, pi) => (
                          <div key={pi} style={{ fontSize: 12, marginBottom: 5 }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                              <span>{p.ts} · {p.method}</span>
                              <span>Rp {fmt(p.paid)}</span>
                            </div>
                            {p.kembalian > 0 && <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--ok)', fontSize: 11.5 }}><span>Kembalian</span><span>Rp {fmt(p.kembalian)}</span></div>}
                            {p.hutang > 0 && <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--warn)', fontSize: 11.5 }}><span>Hutang</span><span>Rp {fmt(p.hutang)}</span></div>}
                          </div>
                        ))}
                        {isHutang && (
                          <div className="tx-remaining">
                            <span className="rl">Total dibayar: {rp(tx.paid)}</span>
                            <span className="rv">Sisa {rp(tx.remaining)}</span>
                          </div>
                        )}
                      </div>
                    )}
                    <div className="tx-actions">
                      {isHutang && <button className="tx-action-btn primary" onClick={() => handleLunasi(tx)}><Icon name="cash" size={14} /> Lunasi</button>}
                      <button className="tx-action-btn" onClick={() => { onAddTo(tx); onClose(); }}><Icon name="plus" size={14} /> Tambah Item</button>
                      <button className="tx-action-btn"><Icon name="receipt" size={14} /> Struk</button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {!filtered.length && <div style={{ textAlign: 'center', color: 'var(--ink-3)', padding: '48px 20px', fontSize: 13 }}>Tidak ada transaksi ditemukan.</div>}
          <div style={{ height: 10 }} />
        </div>
      </div>
    </div>
  );
}

/* ─── Edit product ─── */
function EditProductModal({ product, cats, onSave, onClose }) {
  const [f, setF] = React.useState({ ...product });
  const set = (k, v) => setF(o => ({ ...o, [k]: v }));
  const [tab, setTab] = React.useState('info');
  const hasV = !!(f.variants && f.variants.length);
  return (
    <div className="scrim" onPointerDown={onClose}>
      <div className="modal" onPointerDown={(e) => e.stopPropagation()}>
        <div className="sheet-grip" style={{ marginBottom: 0 }} />
        <div className="modal-head">
          <div><div className="mt">Ubah Produk</div><div className="ms">SKU {product.barcode}</div></div>
          <button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button>
        </div>
        <div style={{ display: 'flex', gap: 6, padding: '8px 16px 0', flexShrink: 0 }}>
          {['info', hasV ? 'variants' : null].filter(Boolean).map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ height: 32, padding: '0 14px', borderRadius: 'var(--r-chip)', fontSize: 12.5, fontWeight: 600, border: '1px solid',
                borderColor: tab === t ? 'var(--accent)' : 'var(--line-2)',
                background: tab === t ? 'var(--accent-soft)' : 'var(--card)',
                color: tab === t ? 'var(--accent)' : 'var(--ink-2)' }}>
              {t === 'info' ? 'Info Produk' : 'Variasi & Satuan'}
            </button>
          ))}
        </div>
        <div className="modal-body">
          {tab === 'info' && (
            <div className="fgrid">
              <div className="full"><label className="field-label">Nama Produk</label><input className="tinput" value={f.name} onChange={e => set('name', e.target.value)} /></div>
              <div><label className="field-label">Harga Jual (Rp)</label><input className="tinput" type="number" value={f.price} onChange={e => set('price', +e.target.value)} /></div>
              <div><label className="field-label">Stok</label><input className="tinput" type="number" value={f.stock} onChange={e => set('stock', +e.target.value)} /></div>
              <div><label className="field-label">Satuan</label><input className="tinput" value={f.unit} onChange={e => set('unit', e.target.value)} /></div>
              <div><label className="field-label">Kategori</label>
                <select className="tinput" value={f.cat} onChange={e => set('cat', e.target.value)}>
                  {cats.filter(c => c.id !== 'all').map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>
              <div className="full"><label className="field-label">Barcode</label><input className="tinput" value={f.barcode} onChange={e => set('barcode', e.target.value)} /></div>
            </div>
          )}
          {tab === 'variants' && hasV && (f.variants || []).map((v, i) => (
            <div key={v.id} style={{ background: 'var(--field)', borderRadius: 12, padding: '12px 13px', marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-3)', marginBottom: 8 }}>Variasi {i + 1}</div>
              <div className="fgrid">
                <div className="full"><label className="field-label">Label</label><input className="tinput" value={v.label} onChange={e => { const vs = [...f.variants]; vs[i] = { ...vs[i], label: e.target.value }; set('variants', vs); }} /></div>
                <div><label className="field-label">Harga (Rp)</label><input className="tinput" type="number" value={v.price} onChange={e => { const vs = [...f.variants]; vs[i] = { ...vs[i], price: +e.target.value }; set('variants', vs); }} /></div>
                <div><label className="field-label">Stok</label><input className="tinput" type="number" value={v.stock} onChange={e => { const vs = [...f.variants]; vs[i] = { ...vs[i], stock: +e.target.value }; set('variants', vs); }} /></div>
                <div className="full"><label className="field-label">Barcode</label><input className="tinput" value={v.barcode} onChange={e => { const vs = [...f.variants]; vs[i] = { ...vs[i], barcode: e.target.value }; set('variants', vs); }} /></div>
              </div>
            </div>
          ))}
        </div>
        <div className="modal-foot">
          <button className="btn ghost danger" onClick={onClose}><Icon name="trash" size={14} /> Hapus</button>
          <div style={{ flex: 1 }} />
          <button className="btn" onClick={onClose}>Batal</button>
          <button className="btn primary" onClick={() => onSave(f)}><Icon name="check" size={14} /> Simpan</button>
        </div>
      </div>
    </div>
  );
}

/* ─── Held orders drawer ─── */
function ContextDrawer({ held, onClose, onResume }) {
  return (
    <>
      <div className="drawer-scrim" onClick={onClose} />
      <div className="drawer">
        <div className="drawer-head"><span className="dt">Pesanan Ditahan</span><button className="modal-x" onClick={onClose}><Icon name="x" size={15} /></button></div>
        <div className="drawer-body">
          {held.length ? held.map(h => (
            <div className="drow" key={h.id} onClick={() => onResume(h)}>
              <div className="di"><div className="n">{h.name}</div><div className="s">{h.items} item · {h.time}</div></div>
              <div className="dv"><div className="a">{rp(h.total)}</div><span className="method-tag Tunai">Lanjutkan →</span></div>
            </div>
          )) : <div style={{ textAlign: 'center', color: 'var(--ink-3)', padding: '48px 16px', fontSize: 13 }}>Tidak ada pesanan ditahan.</div>}
        </div>
      </div>
    </>
  );
}

/* CSS for spin animation (receipt loading) */
const _spinStyle = document.createElement('style');
_spinStyle.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
document.head.appendChild(_spinStyle);

Object.assign(window, { PriceEditorSheet, PaymentPanel, ReceiptModal, ReceiptContent,
  VariantSheet, TransactionSheet, EditProductModal, ContextDrawer, QRCode });
