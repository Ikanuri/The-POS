/* components.jsx — shared primitives + icons + StatusBar + BottomNav */

const fmt = (n) => new Intl.NumberFormat('id-ID').format(Math.round(n));
const rp  = (n) => 'Rp ' + fmt(n);

/* ─── Icons ─── */
const ICONS = {
  search:   'M11 4a7 7 0 1 0 4.2 12.6l4.1 4.1 1.4-1.4-4.1-4.1A7 7 0 0 0 11 4Zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z',
  scan:     'M3 5a2 2 0 0 1 2-2h3v2H5v3H3V5Zm13-2h3a2 2 0 0 1 2 2v3h-2V5h-3V3ZM3 16h2v3h3v2H5a2 2 0 0 1-2-2v-3Zm18 0v3a2 2 0 0 1-2 2h-3v-2h3v-3h2ZM6 7h1.4v10H6V7Zm2.6 0H10v10H8.6V7Zm2.7 0h2v10h-2V7Zm3.2 0H16v10h-1.5V7Zm2.8 0H18v10h-1.4V7Z',
  moon:     'M12.5 3a9 9 0 1 0 8.5 12 7 7 0 0 1-8.5-8.5c.1-1.3.5-2.5 0-3.5Z',
  sun:      'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0-5v3m0 14v3M2 12h3m14 0h3M4.9 4.9l2.1 2.1m10 10 2.1 2.1m0-14.2-2.1 2.1m-10 10-2.1 2.1',
  clock:    'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 2a7 7 0 1 1 0 14 7 7 0 0 1 0-14Zm-1 2v6l5 3 1-1.7-4-2.3V7h-2Z',
  plus:     'M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z',
  minus:    'M5 11h14v2H5z',
  trash:    'M9 3h6l1 2h4v2H4V5h4l1-2Zm-3 6h12l-1 11a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 9Z',
  edit:     'M4 16.5 14.5 6l3.5 3.5L7.5 20H4v-3.5ZM16 4.5 18 2.5a1.5 1.5 0 0 1 2 0l1.5 1.5a1.5 1.5 0 0 1 0 2L19.5 8 16 4.5Z',
  note:     'M5 3h10l4 4v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm9 1.5V8h3.5L14 4.5ZM7 11h10v1.5H7V11Zm0 4h10v1.5H7V15Z',
  pause:    'M7 4h3v16H7V4Zm7 0h3v16h-3V4Z',
  cash:     'M3 6h18a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm2 2v8h14V8H5Zm7 1.5A2.5 2.5 0 1 1 12 14.5 2.5 2.5 0 0 1 12 9.5Z',
  qr:       'M3 3h8v8H3V3Zm2 2v4h4V5H5Zm8-2h8v8h-8V3Zm2 2v4h4V5h-4ZM3 13h8v8H3v-8Zm2 2v4h4v-4H5Zm10-2h2v2h-2v-2Zm4 0h2v2h-2v-2Zm-4 4h2v4h-2v-4Zm4 0h2v4h-2v-4Z',
  card:     'M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Zm1 4v2h16V9H4Zm0 4v3h7v-3H4Z',
  check:    'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2Z',
  x:        'M6 5l6 6 6-6 1.4 1.4-6 6 6 6L18 19.8l-6-6-6 6L4.6 18.4l6-6-6-6L6 5Z',
  bag:      'M7 7V6a5 5 0 0 1 10 0v1h3l-1 13a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 7h3Zm2 0h6V6a3 3 0 0 0-6 0v1Z',
  receipt:  'M5 2h14v20l-3-2-2 2-2-2-2 2-2-2-3 2V2Zm3 5h8v1.6H8V7Zm0 4h8v1.6H8V11Zm0 4h5v1.6H8V15Z',
  layers:   'M12 2 2 7l10 5 10-5-10-5Zm0 12.5L4 10.5 2 11.5l10 5 10-5-2-1-8 4Z',
  home:     'M12 3 3 10h2v9h5v-6h4v6h5v-9h2L12 3Z',
  chart:    'M3 3v18h18M7 16l4-8 4 6 3-4',
  gear:     'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm-7.8 5-1.2-.7V9.7l1.2-.7a8 8 0 0 1 1.1-2.6L5 5.2l2.4-2.4 1.2.3a8 8 0 0 1 2.6-1.1L12 .8l2.8 1.1 .7 1.2c1 .3 1.8.7 2.6 1.1l1.2-.3L21.6 6l-.3 1.2c.4.8.8 1.7 1.1 2.6l1.2.7v3.4l-1.2.7a8 8 0 0 1-1.1 2.6l.3 1.2-2.4 2.4-1.2-.3a8 8 0 0 1-2.6 1.1L14.8 23l-2.8-1.1-.7-1.2a8 8 0 0 1-2.6-1.1l-1.2.3L5 18.6l.3-1.2a8 8 0 0 1-1.1-2.6Z',
  grid:     'M3 3h7v7H3V3Zm11 0h7v7h-7V3ZM3 14h7v7H3v-7Zm11 0h7v7h-7v-7Z',
  list:     'M4 6h16v2H4V6Zm0 5h16v2H4v-2Zm0 5h16v2H4v-2Z',
  chevdown: 'M6 9l6 6 6-6',
  arrow:    'M5 12h14M12 5l7 7-7 7',
};

function Icon({ name, size = 20, stroke = false, sw = 1.7, ...rest }) {
  const d = ICONS[name] || '';
  if (stroke) return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...rest}>
      <path d={d} />
    </svg>
  );
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" {...rest}>
      <path d={d} />
    </svg>
  );
}

/* ─── Status bar ─── */
function StatusBar() {
  const [time, setTime] = React.useState('');
  React.useEffect(() => {
    const tick = () => setTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }));
    tick();
    const t = setInterval(tick, 15000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="status-bar">
      <span className="time">{time}</span>
      <div className="icons">
        {/* signal */}
        <svg width="17" height="12" viewBox="0 0 17 12" fill="currentColor">
          <rect x="0" y="5" width="3" height="7" rx="1" opacity="0.35"/>
          <rect x="4.5" y="3" width="3" height="9" rx="1" opacity="0.55"/>
          <rect x="9" y="1" width="3" height="11" rx="1" opacity="0.75"/>
          <rect x="13.5" y="0" width="3" height="12" rx="1"/>
        </svg>
        {/* wifi */}
        <svg width="16" height="12" viewBox="0 0 20 14" fill="currentColor">
          <path d="M10 2.5C13.5 2.5 16.6 4.2 18.5 6.8L20 5.2C17.6 2 14 0 10 0 6 0 2.4 2 0 5.2L1.5 6.8C3.4 4.2 6.5 2.5 10 2.5Z"/>
          <path d="M10 6C12.4 6 14.5 7.1 16 8.8L17.5 7.2C15.6 5.2 13 4 10 4 7 4 4.4 5.2 2.5 7.2L4 8.8C5.5 7.1 7.6 6 10 6Z"/>
          <circle cx="10" cy="12" r="2"/>
        </svg>
        {/* battery */}
        <svg width="25" height="12" viewBox="0 0 25 12" fill="currentColor">
          <rect x="0" y="1" width="22" height="10" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.2"/>
          <rect x="22.5" y="3.5" width="2" height="5" rx="1" opacity="0.4"/>
          <rect x="1.5" y="2.5" width="16" height="7" rx="1.5" opacity="0.9"/>
        </svg>
      </div>
    </div>
  );
}

/* ─── Bottom nav ─── */
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Ringkasan', icon: 'home',    href: 'Dashboard.html' },
  { id: 'kasir',     label: 'Kasir',     icon: 'bag',     href: 'Kasir POS.html' },
  { id: 'laporan',   label: 'Laporan',   icon: 'chart',   href: 'Laporan.html' },
  { id: 'pengaturan',label: 'Pengaturan',icon: 'gear',    href: 'Pengaturan.html' },
];
function BottomNav({ active = 'kasir' }) {
  return (
    <div className="bottom-nav">
      {NAV_ITEMS.map((n) => (
        <a key={n.id} className={'nav-item' + (n.id === active ? ' active' : '')} href={n.href}>
          <Icon name={n.icon} size={20} stroke sw={1.6} />
          {n.label}
        </a>
      ))}
    </div>
  );
}

/* ─── Product card (grid) ─── */
function ProductCard({ p, qty, onAdd, onInc, onDec, onLongPress }) {
  const timer = React.useRef(null);
  const [pressing, setPressing] = React.useState(false);
  const low = p.stock > 0 && p.stock <= 12;
  const out = p.stock === 0;

  const start = (e) => {
    if (e.button === 2) return;
    setPressing(true);
    timer.current = setTimeout(() => { setPressing(false); onLongPress(p); }, 480);
  };
  const cancel = () => { clearTimeout(timer.current); setPressing(false); };

  return (
    <div
      className={'pcard' + (qty ? ' incart' : '') + (pressing ? ' pressing' : '')}
      onPointerDown={start} onPointerUp={cancel} onPointerLeave={cancel}
      onContextMenu={(e) => { e.preventDefault(); onLongPress(p); }}
    >
      <span className="longpress-hint"><Icon name="edit" size={13} /></span>
      <div className="pname">{p.name}</div>
      <div className="pmeta">
        <span className={'tag' + (out ? ' stock-out' : low ? ' stock-low' : '')}>
          {out ? 'Habis' : 'Stok ' + p.stock}
        </span>
        <span className="tag">/{p.unit}</span>
      </div>
      <div className="pfoot">
        <div className="price">
          <span className="cur">Rp</span>
          <span className="amt">{fmt(p.price)}</span>
        </div>
        {qty ? (
          <div className="qty-group" onPointerDown={(e) => e.stopPropagation()}>
            <button onClick={onDec}><Icon name="minus" size={15} /></button>
            <span className="n">{qty}</span>
            <button onClick={onInc}><Icon name="plus" size={15} /></button>
          </div>
        ) : (
          <button className="add-btn" disabled={out}
            onPointerDown={(e) => e.stopPropagation()} onClick={() => onAdd(p)}>
            <Icon name="plus" size={13} /> Tambah
          </button>
        )}
      </div>
    </div>
  );
}

/* ─── Product row (list view) ─── */
function ProductRow({ p, qty, onAdd, onInc, onDec, onLongPress }) {
  const timer = React.useRef(null);
  const [pressing, setPressing] = React.useState(false);
  const low = p.stock > 0 && p.stock <= 12;
  const out = p.stock === 0;

  const start = () => { setPressing(true); timer.current = setTimeout(() => { setPressing(false); onLongPress(p); }, 480); };
  const cancel = () => { clearTimeout(timer.current); setPressing(false); };

  return (
    <div
      className={'pcard-list' + (qty ? ' incart' : '') + (pressing ? ' pressing' : '')}
      onPointerDown={start} onPointerUp={cancel} onPointerLeave={cancel}
      onContextMenu={(e) => { e.preventDefault(); onLongPress(p); }}
    >
      <div className="pl-info">
        <div className="pl-name">{p.name}</div>
        <div className="pl-meta">
          <span className={'tag' + (out ? ' stock-out' : low ? ' stock-low' : '')}>
            {out ? 'Habis' : 'Stok ' + p.stock}
          </span>
          <span className="tag">/{p.unit}</span>
        </div>
      </div>
      <div className="pl-price">{rp(p.price)}</div>
      <div className="pl-stepper" onPointerDown={(e) => e.stopPropagation()}>
        {qty ? (
          <div className="qty-group">
            <button onClick={onDec}><Icon name="minus" size={14} /></button>
            <span className="n">{qty}</span>
            <button onClick={onInc}><Icon name="plus" size={14} /></button>
          </div>
        ) : (
          <button className="add-btn" disabled={out} onClick={() => onAdd(p)}>
            <Icon name="plus" size={13} />
          </button>
        )}
      </div>
    </div>
  );
}

/* ─── Cart item ─── */
function CartItem({ p, qty, onInc, onDec }) {
  return (
    <div className="citem">
      <div className="ci-main">
        <div className="ci-name">{p.name}</div>
        <div className="ci-sub">{rp(p.price)} · /{p.unit}</div>
      </div>
      <div className="ci-right">
        <div className="ci-total">{rp(p.price * qty)}</div>
        <div className="ci-step">
          <button onClick={onDec}><Icon name="minus" size={13} /></button>
          <span className="n">{qty}</span>
          <button onClick={onInc}><Icon name="plus" size={13} /></button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Icon, fmt, rp, StatusBar, BottomNav, ProductCard, ProductRow, CartItem, NAV_ITEMS });
