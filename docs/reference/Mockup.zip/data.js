/* data.js — BerkahPOS catalog + history + config */
(function () {

  const CATS = [
    { id: 'all',     label: 'Semua' },
    { id: 'sembako', label: 'Sembako' },
    { id: 'minuman', label: 'Minuman' },
    { id: 'snack',   label: 'Snack' },
    { id: 'bumbu',   label: 'Bumbu Dapur' },
    { id: 'rumah',   label: 'Keb. Rumah' },
    { id: 'rokok',   label: 'Rokok' },
  ];

  /* altPrices: array of {label, price} — shown in price editor */
  const PRODUCTS = [
    { id:'p1',  name:'Beras Pandan Wangi 5kg',   price:68000,  unit:'sak',   stock:42,  cat:'sembako', barcode:'8991234001',
      altPrices:[{label:'Retail',price:68000},{label:'Grosir',price:65000},{label:'Langganan',price:63000}] },
    { id:'p2',  name:'Beras Setra Ramos 25kg',    price:312000, unit:'sak',   stock:8,   cat:'sembako', barcode:'8991234002',
      altPrices:[{label:'Retail',price:312000},{label:'Grosir',price:298000}] },
    { id:'p3',  name:'Minyak Goreng Sania 2L',    price:38500,  unit:'pouch', stock:64,  cat:'sembako', barcode:'8991234003',
      altPrices:[{label:'Retail',price:38500},{label:'Grosir',price:36500},{label:'Langganan',price:35000}] },
    { id:'p4',  name:'Minyak Goreng Curah 1kg',   price:16500,  unit:'kg',    stock:120, cat:'sembako', barcode:'8991234004',
      altPrices:[{label:'Retail',price:16500},{label:'Grosir',price:15500}] },
    { id:'p5',  name:'Gula Pasir GMP 1kg',        price:15500,  unit:'kg',    stock:88,  cat:'sembako', barcode:'8991234005',
      altPrices:[{label:'Retail',price:15500},{label:'Grosir',price:14800},{label:'Agen',price:14000}] },
    { id:'p6',  name:'Tepung Terigu Segitiga 1kg', price:13000, unit:'pak',   stock:54,  cat:'sembako', barcode:'8991234006',
      altPrices:[{label:'Retail',price:13000},{label:'Grosir',price:12000}] },
    { id:'p7',  name:'Telur Ayam Negeri',         price:27500,  unit:'kg',    stock:36,  cat:'sembako', barcode:'8991234007',
      altPrices:[{label:'Retail',price:27500},{label:'Grosir',price:26000}] },
    {
      id:'p8', name:'Indomie Goreng', price:3200, unit:'pcs', stock:540, cat:'sembako', barcode:'8991234008',
      altPrices:[{label:'Satuan',price:3200},{label:'Grosir',price:3000}],
      variants:[
        { id:'v1', label:'Satuan (1 pcs)',   price:3200,  unit:'pcs', barcode:'8991234008', stock:540 },
        { id:'v2', label:'Renteng (10 pcs)', price:30000, unit:'rntg',barcode:'8991234081', stock:120 },
        { id:'v3', label:'Dus (40 pcs)',     price:76000, unit:'dus', barcode:'8991234082', stock:22  },
      ],
    },
    { id:'p9',  name:'Susu Kental Manis Frisian', price:11500, unit:'kaleng',stock:96,  cat:'sembako', barcode:'8991234009' },
    {
      id:'p11', name:'Aqua', price:3500, unit:'botol', stock:240, cat:'minuman', barcode:'8991234011',
      altPrices:[{label:'Retail',price:3500},{label:'Grosir',price:3200}],
      variants:[
        { id:'v1', label:'Botol 600ml',      price:3500,  unit:'btl',  barcode:'8991234011', stock:240 },
        { id:'v2', label:'Galon 19L',        price:22000, unit:'galon',barcode:'8991234112', stock:18  },
        { id:'v3', label:'Dus 600ml (24)',   price:72000, unit:'dus',  barcode:'8991234113', stock:30  },
      ],
    },
    { id:'p12', name:'Teh Pucuk Harum 350ml',    price:3000,  unit:'pcs',   stock:180, cat:'minuman', barcode:'8991234012' },
    {
      id:'p13', name:'Kopi Kapal Api', price:1500, unit:'sachet', stock:600, cat:'minuman', barcode:'8991234013',
      altPrices:[{label:'Eceran',price:1500},{label:'Renteng',price:14500}],
      variants:[
        { id:'v1', label:'Sachet Classic',   price:1500,  unit:'sachet',barcode:'8991234013', stock:600 },
        { id:'v2', label:'Sachet Hitam Pkt', price:2000,  unit:'sachet',barcode:'8991234131', stock:300 },
        { id:'v3', label:'Renteng (10s)',     price:14500, unit:'rntg', barcode:'8991234132', stock:48  },
        { id:'v4', label:'Kaleng 200g',       price:38000, unit:'klng', barcode:'8991234133', stock:24  },
      ],
    },
    { id:'p14', name:'Sprite 1.5L',              price:16000, unit:'pcs',   stock:72,  cat:'minuman', barcode:'8991234014' },
    { id:'p15', name:'Pocari Sweat 500ml',        price:9500,  unit:'pcs',   stock:60,  cat:'minuman', barcode:'8991234015' },
    { id:'p16', name:'Chitato Sapi Panggang',     price:9000,  unit:'pcs',   stock:84,  cat:'snack',   barcode:'8991234016' },
    { id:'p17', name:'Beng Beng',                 price:2000,  unit:'pcs',   stock:400, cat:'snack',   barcode:'8991234017' },
    { id:'p18', name:'Biskuit Roma Kelapa',        price:8500,  unit:'pak',   stock:110, cat:'snack',   barcode:'8991234018' },
    { id:'p19', name:'Kacang Garuda 200g',        price:11000, unit:'pcs',   stock:66,  cat:'snack',   barcode:'8991234019' },
    { id:'p20', name:'Royco Ayam 230g',           price:9500,  unit:'pcs',   stock:48,  cat:'bumbu',   barcode:'8991234020' },
    { id:'p21', name:'Kecap Bango 220ml',         price:14500, unit:'pcs',   stock:70,  cat:'bumbu',   barcode:'8991234021' },
    { id:'p22', name:'Saus ABC Sachet',            price:500,   unit:'pcs',   stock:900, cat:'bumbu',   barcode:'8991234022' },
    { id:'p23', name:'Garam Dolpin 250g',          price:3000,  unit:'pcs',   stock:130, cat:'bumbu',   barcode:'8991234023' },
    {
      id:'p24', name:'Sabun Lifebuoy', price:5000, unit:'btng', stock:120, cat:'rumah', barcode:'8991234024',
      altPrices:[{label:'Batangan',price:5000},{label:'4-pak',price:16500}],
      variants:[
        { id:'v1', label:'Batangan 80g',   price:5000,  unit:'btng',barcode:'8991234024', stock:120 },
        { id:'v2', label:'Paket 4 Batang', price:16500, unit:'pak', barcode:'8991234241', stock:58  },
        { id:'v3', label:'Cair 450ml',     price:18000, unit:'btl', barcode:'8991234242', stock:34  },
      ],
    },
    { id:'p25', name:'Rinso Anti Noda 770g',      price:22000, unit:'pcs',   stock:40,  cat:'rumah',   barcode:'8991234025' },
    { id:'p26', name:'Sunlight Jeruk 750ml',      price:14000, unit:'pcs',   stock:52,  cat:'rumah',   barcode:'8991234026' },
    { id:'p27', name:'Pepsodent 190g',            price:13500, unit:'pcs',   stock:44,  cat:'rumah',   barcode:'8991234027' },
    { id:'p28', name:'Gudang Garam Surya 16',     price:32000, unit:'bks',   stock:90,  cat:'rokok',   barcode:'8991234028' },
    { id:'p29', name:'Sampoerna Mild 16',         price:33500, unit:'bks',   stock:76,  cat:'rokok',   barcode:'8991234029' },
    { id:'p30', name:'Djarum Super 12',           price:24000, unit:'bks',   stock:64,  cat:'rokok',   barcode:'8991234030' },
  ];

  const HELD = [
    { id:'h1', name:'Bu Sari',       items:7,  total:184500,  time:'09:42' },
    { id:'h2', name:'Toko Pak Eko',  items:23, total:1240000, time:'09:15' },
  ];

  const HISTORY = [
    {
      id:'t1041', customer:'Bu Sari', note:'', internalNote:'',
      items:[
        { name:'Beras Pandan Wangi 5kg', qty:1, price:68000, unit:'sak', note:'', ts:'10:18' },
        { name:'Minyak Goreng Sania 2L', qty:1, price:38500, unit:'pouch', note:'', ts:'10:18' },
      ],
      subtotal:106500, discount:0, total:106500,
      payments:[{ ts:'10:18', method:'Tunai', paid:106500, kembalian:0, hutang:0 }],
      paid:106500, remaining:0, status:'lunas', time:'10:18',
    },
    {
      id:'t1040', customer:'Toko Maju Jaya', note:'Grosir besar', internalNote:'Diskon negosiasi',
      items:[
        { name:'Indomie Goreng — Dus (40 pcs)', qty:12, price:76000, unit:'dus', note:'', ts:'10:05' },
        { name:'Aqua — Dus 600ml (24)',          qty:5,  price:72000, unit:'dus', note:'', ts:'10:05' },
      ],
      subtotal:1272000, discount:25440, total:1246560,
      payments:[{ ts:'10:05', method:'Tunai', paid:500000, kembalian:0, hutang:746560 }],
      paid:500000, remaining:746560, status:'belum_lunas', time:'10:05',
    },
    {
      id:'t1039', customer:'Pak Hendra', note:'', internalNote:'',
      items:[
        { name:'Gula Pasir GMP 1kg', qty:5, price:15500, unit:'kg',  note:'', ts:'09:58' },
        { name:'Teh Pucuk Harum',    qty:3, price:3000,  unit:'pcs', note:'', ts:'09:58' },
      ],
      subtotal:86500, discount:0, total:86500,
      payments:[{ ts:'09:58', method:'QRIS', paid:86500, kembalian:0, hutang:0 }],
      paid:86500, remaining:0, status:'lunas', time:'09:58',
    },
    {
      id:'t1038', customer:'CV Sinar Baru', note:'Langganan bulanan', internalNote:'Bayar akhir bulan',
      items:[
        { name:'Sampoerna Mild 16',     qty:10, price:33500, unit:'bks', note:'', ts:'09:36' },
        { name:'Gudang Garam Surya 16', qty:10, price:32000, unit:'bks', note:'', ts:'09:36' },
        { name:'Rinso Anti Noda 770g',  qty:20, price:22000, unit:'pcs', note:'', ts:'09:36' },
        { name:'Sunlight Jeruk 750ml',  qty:15, price:14000, unit:'pcs', note:'', ts:'09:36' },
        { name:'Susu Kental Manis',     qty:24, price:11500, unit:'kaleng', note:'', ts:'09:36' },
      ],
      subtotal:1721000, discount:51630, total:1669370,
      payments:[{ ts:'09:36', method:'Kartu', paid:1669370, kembalian:0, hutang:0 }],
      paid:1669370, remaining:0, status:'lunas', time:'09:36',
    },
    {
      id:'t1037', customer:'Bu Ratna', note:'', internalNote:'',
      items:[
        { name:'Kopi Kapal Api — Renteng', qty:4,  price:14500, unit:'rntg', note:'', ts:'09:21' },
        { name:'Garam Dolpin 250g',        qty:3,  price:3000,  unit:'pcs',  note:'', ts:'09:21' },
        { name:'Saus ABC Sachet',          qty:10, price:500,   unit:'pcs',  note:'', ts:'09:21' },
      ],
      subtotal:72000, discount:0, total:72000,
      payments:[{ ts:'09:21', method:'Tunai', paid:50000, kembalian:0, hutang:22000 }],
      paid:50000, remaining:22000, status:'belum_lunas', time:'09:21',
    },
  ];

  /* Store info + payment methods — mirrored in localStorage by Pengaturan */
  const DEFAULT_CONFIG = {
    store: {
      name:    'Berkah Grosir',
      address: 'Jl. Pasar Baru No. 12',
      phone:   '0895-1765-6787',
      telegram:'',
      receiptNote: 'Terima kasih atas kepercayaan Anda!',
    },
    paymentMethods: [
      { id:'tunai', type:'tunai',   name:'Tunai' },
      { id:'qris',  type:'qris',    name:'QRIS',  meta:{ qrValue:'00020101021226580014ID.CO.BNI.WWW011893600009150000000152040000530360054081234567890802ID5916BerkahGrosir6007Jakarta63041234' } },
      { id:'bri',   type:'bank',    name:'BRI',   data:'1234-01-012345-30-7 a/n Berkah Grosir' },
      { id:'bca',   type:'bank',    name:'BCA',   data:'8123456789 a/n Berkah Grosir' },
      { id:'ovo',   type:'ewallet', name:'OVO',   data:'0895-1765-6787' },
      { id:'dana',  type:'ewallet', name:'DANA',  data:'0895-1765-6787' },
    ],
  };

  /* Merge with any user-saved config */
  function getConfig() {
    try {
      const saved = JSON.parse(localStorage.getItem('pos_config') || '{}');
      return {
        store: { ...DEFAULT_CONFIG.store, ...(saved.store || {}) },
        paymentMethods: saved.paymentMethods || DEFAULT_CONFIG.paymentMethods,
      };
    } catch { return DEFAULT_CONFIG; }
  }

  /* Daily transaction counter */
  const today = new Date().toISOString().split('T')[0];
  let txCtr = parseInt(localStorage.getItem('pos_tx_counter_' + today) || '1040');
  function nextTxId() {
    txCtr++;
    localStorage.setItem('pos_tx_counter_' + today, String(txCtr));
    return 't' + txCtr;
  }

  window.POS = { CATS, PRODUCTS, HELD, HISTORY, DEFAULT_CONFIG, getConfig, nextTxId };
})();
