/* cashier.jsx — phone CashierApp · variant-aware · price overrides · item notes · receipt */

function HoldDropdown({ held, hasCart, onHoldCurrent, onResume, onClose }) {
  return (
    <div className="hold-dropdown-wrap" style={{ position:'absolute', top:0, left:0, right:0, zIndex:25 }}>
      <div style={{ position:'fixed', inset:0, zIndex:24 }} onClick={onClose} />
      <div className="hold-dropdown" style={{ position:'relative', zIndex:25 }}>
        <div className="hd-label">{hasCart ? 'Tahan atau lanjutkan pesanan' : 'Pesanan ditahan'}</div>
        <div className="hd-scroll">
          {hasCart && (
            <div className="hd-card hd-new-hold" onClick={() => { onHoldCurrent(); onClose(); }}>
              <Icon name="pause" size={20} />
              <span style={{ fontSize:12, fontWeight:700 }}>Tahan Sekarang</span>
            </div>
          )}
          {held.length === 0 && !hasCart && (
            <div style={{ fontSize:12.5, color:'var(--ink-3)', padding:'16px 4px' }}>Tidak ada pesanan ditahan.</div>
          )}
          {held.map(h => (
            <div className="hd-card" key={h.id} onClick={() => { onResume(h); onClose(); }}>
              <div className="hd-name">{h.name}</div>
              <div className="hd-meta">{h.items} item · {h.time}</div>
              <div className="hd-total">{rp(h.total)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Cart item (with inline price edit + notes) ─── */
function CartItemRow({ cartKey, item, qty, priceOverride, itemNote, internalNote,
  onInc, onDec, onOpenPriceEdit, onNoteChange, onInternalNoteChange, byId }) {
  const price = priceOverride != null ? priceOverride : item.price;
  const [noteActive, setNoteActive] = React.useState(!!itemNote);

  return (
    <div className="citem" style={{ flexDirection:'column', alignItems:'stretch', gap:4 }}>
      {/* top row: name + qty stepper */}
      <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
        <div className="ci-main" style={{ flex:1, minWidth:0 }}>
          <div className="ci-name">{item.name}</div>
          {/* price row — tap to edit */}
          <div style={{ display:'flex', alignItems:'center', gap:5, marginTop:3 }}>
            <button className="ci-note-btn" style={{ fontSize:12.5, fontWeight:600, color: priceOverride != null ? 'var(--accent)' : 'var(--ink-3)' }}
              onClick={() => onOpenPriceEdit(cartKey)}>
              {rp(price)}/{item.unit}
              {priceOverride != null && <span style={{ fontSize:10, marginLeft:4, opacity:.7 }}>(diubah)</span>}
            </button>
          </div>
        </div>
        <div className="ci-right">
          <div className="ci-total">{rp(price * qty)}</div>
          <div className="ci-step">
            <button onClick={() => onDec(cartKey)}><Icon name="minus" size={13} /></button>
            <span className="n">{qty}</span>
            <button onClick={() => onInc(cartKey)}><Icon name="plus" size={13} /></button>
          </div>
        </div>
      </div>

      {/* receipt note */}
      {(noteActive || itemNote) ? (
        <input className="ci-note-input" placeholder="Catatan item (muncul di struk)…"
          value={itemNote || ''} autoFocus={noteActive && !itemNote}
          onChange={e => onNoteChange(cartKey, e.target.value)}
          onBlur={() => setNoteActive(!!itemNote)} />
      ) : (
        <button className="ci-note-btn" onClick={() => setNoteActive(true)}>
          + Catatan item
        </button>
      )}
    </div>
  );
}

/* ─── Cart bottom sheet ─── */
function CartSheet({ list, note, setNote, internalNote, setInternalNote,
  priceOverrides, itemNotes, onOpenPriceEdit, onNoteChange,
  subtotal, discount, total, count,
  onInc, onDec, onClear, onHold, onPay, onClose }) {

  return (
    <div className="sheet-scrim" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <div className="sheet-grip" />
        <div className="sheet-head">
          <div className="sheet-title">
            <b>Pesanan</b>
            {count > 0 && <span className="pill">{count}</span>}
          </div>
          {list.length > 0 && <button className="sheet-clear" onClick={onClear}>Kosongkan</button>}
        </div>

        {list.length === 0 ? (
          <div className="cart-empty">
            <div className="ico"><Icon name="bag" size={26} /></div>
            <div className="et">Keranjang kosong</div>
            <div className="es">Tambahkan produk dari katalog.</div>
          </div>
        ) : (
          <div className="cart-items">
            {list.map(({ key, item, qty }) => (
              <CartItemRow key={key} cartKey={key} item={item} qty={qty}
                priceOverride={priceOverrides[key]}
                itemNote={itemNotes[key]}
                onInc={onInc} onDec={onDec}
                onOpenPriceEdit={onOpenPriceEdit}
                onNoteChange={onNoteChange} />
            ))}
          </div>
        )}

        {/* Notes */}
        <div className="cart-tools" style={{ flexDirection:'column', gap:6, alignItems:'stretch' }}>
          {/* Receipt note */}
          <div className={'note-field' + (note ? ' has' : '')}>
            <Icon name="note" size={14} />
            <input placeholder="Catatan untuk struk…" value={note} onChange={e => setNote(e.target.value)} />
          </div>
          {/* Internal note */}
          <div className={'internal-note' + (internalNote ? ' has' : '')}>
            <Icon name="layers" size={14} />
            <input placeholder="Catatan internal (tidak di struk)…"
              value={internalNote} onChange={e => setInternalNote(e.target.value)} />
          </div>
          <div style={{ display:'flex', gap:7 }}>
            <button className="btn" style={{ height:36, padding:'0 12px', fontSize:12.5, flex:1 }}
              onClick={onHold} disabled={!list.length}>
              <Icon name="pause" size={14} /> Tahan
            </button>
          </div>
        </div>

        <div className="summary">
          <div className="srow"><span>Subtotal</span><span className="v">{rp(subtotal)}</span></div>
          {discount > 0 && <div className="srow disc"><span>Diskon grosir</span><span className="v">− {rp(discount)}</span></div>}
          <div className="grand"><span className="gl">Total</span><span className="gv">{rp(total)}</span></div>
          <button className="pay-btn" disabled={!list.length} onClick={onPay}>
            <span>Lanjut Pembayaran</span>
            <span className="pb-amt">{rp(total)}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Variant-aware product card ─── */
function VProductCard({ p, cartQty, onOpen, onAdd, onInc, onDec }) {
  const timer = React.useRef(null);
  const [pressing, setPressing] = React.useState(false);
  const out = p.stock === 0 && !(p.variants||[]).some(v => v.stock > 0);

  const start = (e) => { if (e.button === 2) return; setPressing(true); timer.current = setTimeout(() => { setPressing(false); onOpen(p, true); }, 480); };
  const cancel = () => { clearTimeout(timer.current); setPressing(false); };

  return (
    <div className={'pcard'+(cartQty>0?' incart':'')+(pressing?' pressing':'')}
      onPointerDown={start} onPointerUp={cancel} onPointerLeave={cancel}
      onContextMenu={e => { e.preventDefault(); onOpen(p, true); }}>
      <span className="longpress-hint"><Icon name="edit" size={13} /></span>
      {p.variants && cartQty > 0 && <span className="var-badge">{cartQty}</span>}
      <div className="pname">{p.name}</div>
      <div className="pmeta">
        {!p.variants ? (
          <><span className={'tag'+(out?' stock-out':p.stock<=12?' stock-low':'')}>{out?'Habis':'Stok '+p.stock}</span><span className="tag">/{p.unit}</span></>
        ) : (
          <span className="tag" style={{ color:'var(--accent)', background:'var(--accent-soft)' }}>{p.variants.length} variasi</span>
        )}
      </div>
      <div className="pfoot">
        <div className="price">
          <span className="cur">Rp</span>
          <span className="amt">{p.variants ? fmt(Math.min(...p.variants.map(v=>v.price)))+'+' : fmt(p.price)}</span>
        </div>
        {p.variants ? (
          <button className="add-btn" disabled={out} onPointerDown={e=>e.stopPropagation()} onClick={()=>onOpen(p,false)}>
            {cartQty>0 ? <><Icon name="layers" size={13}/> Ubah</> : <><Icon name="plus" size={13}/> Pilih</>}
          </button>
        ) : cartQty > 0 ? (
          <div className="qty-group" onPointerDown={e=>e.stopPropagation()}>
            <button onClick={()=>onDec(p.id)}><Icon name="minus" size={15}/></button>
            <span className="n">{cartQty}</span>
            <button onClick={()=>onInc(p.id)}><Icon name="plus" size={15}/></button>
          </div>
        ) : (
          <button className="add-btn" disabled={out} onPointerDown={e=>e.stopPropagation()} onClick={()=>onAdd(p)}>
            <Icon name="plus" size={13}/> Tambah
          </button>
        )}
      </div>
    </div>
  );
}

/* ─── Variant-aware product row ─── */
function VProductRow({ p, cartQty, onOpen, onAdd, onInc, onDec }) {
  const timer = React.useRef(null);
  const out = p.stock === 0 && !(p.variants||[]).some(v=>v.stock>0);
  const start = ()=>{ timer.current = setTimeout(()=>onOpen(p,true), 480); };
  const cancel = ()=>clearTimeout(timer.current);
  return (
    <div className={'pcard-list'+(cartQty>0?' incart':'')}
      onPointerDown={start} onPointerUp={cancel} onPointerLeave={cancel}
      onContextMenu={e=>{ e.preventDefault(); onOpen(p,true); }}>
      <div className="pl-info">
        <div className="pl-name">{p.name}</div>
        <div className="pl-meta">
          {p.variants ? <span className="tag" style={{color:'var(--accent)',background:'var(--accent-soft)'}}>{p.variants.length} variasi</span>
            : <span className={'tag'+(out?' stock-out':'')}>Stok {p.stock}</span>}
          {!p.variants && <span className="tag">/{p.unit}</span>}
        </div>
      </div>
      <div className="pl-price">{p.variants ? 'Rp '+fmt(Math.min(...p.variants.map(v=>v.price)))+'+' : rp(p.price)}</div>
      <div className="pl-stepper" onPointerDown={e=>e.stopPropagation()}>
        {p.variants ? (
          <button className="add-btn" onClick={()=>onOpen(p,false)}>
            {cartQty>0 ? <Icon name="layers" size={13}/> : <Icon name="plus" size={13}/>}
          </button>
        ) : cartQty > 0 ? (
          <div className="qty-group">
            <button onClick={()=>onDec(p.id)}><Icon name="minus" size={14}/></button>
            <span className="n">{cartQty}</span>
            <button onClick={()=>onInc(p.id)}><Icon name="plus" size={14}/></button>
          </div>
        ) : (
          <button className="add-btn" disabled={out} onClick={()=>onAdd(p)}><Icon name="plus" size={13}/></button>
        )}
      </div>
    </div>
  );
}

/* ─── Main App ─── */
function CashierApp({ theme, onToggleTheme, layout }) {
  const { CATS } = window.POS;
  const [products, setProducts]     = React.useState(window.POS.PRODUCTS);
  const [history, setHistory]       = React.useState(window.POS.HISTORY);
  const [cart, setCart]             = React.useState({});
  const [priceOverrides, setPrices] = React.useState({}); // cartKey -> price
  const [itemNotes, setItemNotes]   = React.useState({}); // cartKey -> note string
  const [note, setNote]             = React.useState('');
  const [internalNote, setIntNote]  = React.useState('');
  const [query, setQuery]           = React.useState('');
  const [cat, setCat]               = React.useState('all');
  const [viewMode, setViewMode]     = React.useState('grid');
  const [held, setHeld]             = React.useState(window.POS.HELD);

  const [variantProd, setVariantProd]   = React.useState(null);
  const [editProd, setEditProd]         = React.useState(null);
  const [priceEditKey, setPriceEditKey] = React.useState(null);
  const [payOpen, setPayOpen]           = React.useState(false);
  const [sheetOpen, setSheet]           = React.useState(false);
  const [holdOpen, setHoldOpen]         = React.useState(false);
  const [txSheetOpen, setTxSheet]       = React.useState(false);
  const [scan, setScan]                 = React.useState(false);
  const [receiptTx, setReceiptTx]       = React.useState(null);
  const [toast, setToast]               = React.useState(null);
  const searchRef = React.useRef(null);

  /* flat item map */
  const byId = React.useMemo(() => {
    const map = {};
    products.forEach(p => {
      map[p.id] = p;
      (p.variants||[]).forEach(v => {
        map[`${p.id}:${v.id}`] = { id:`${p.id}:${v.id}`, name:`${p.name} — ${v.label}`, price:v.price, unit:v.unit, barcode:v.barcode, stock:v.stock, altPrices:p.altPrices||[] };
      });
    });
    return map;
  }, [products]);

  const flash = (msg) => { setToast(msg); clearTimeout(flash._t); flash._t = setTimeout(()=>setToast(null), 2200); };

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter(p =>
      (cat==='all'||p.cat===cat) &&
      (!q || p.name.toLowerCase().includes(q) || p.barcode?.includes(q) || (p.variants||[]).some(v=>v.barcode.includes(q)))
    );
  }, [products, cat, query]);

  const list = React.useMemo(() =>
    Object.entries(cart).map(([key,qty])=>({ key, item:byId[key], qty })).filter(x=>x.item),
    [cart, byId]);

  const count    = list.reduce((s,x)=>s+x.qty, 0);
  const subtotal = list.reduce((s,x)=>{
    const price = priceOverrides[x.key] != null ? priceOverrides[x.key] : x.item.price;
    return s + price * x.qty;
  }, 0);
  const discount = subtotal>=1000000 ? Math.round(subtotal*.03)
    : subtotal>=500000 ? Math.round(subtotal*.02)
    : subtotal>=250000 ? Math.round(subtotal*.01) : 0;
  const total = subtotal - discount;

  const addPlain = (p) => setCart(c => ({ ...c, [p.id]:(c[p.id]||0)+1 }));
  const inc = (key) => setCart(c => ({ ...c, [key]:(c[key]||0)+1 }));
  const dec = (key) => setCart(c => {
    const n = (c[key]||0)-1; const nc = {...c};
    if(n<=0){ delete nc[key]; delete priceOverrides[key]; } else nc[key]=n; return nc;
  });
  const clearCart = () => { setCart({}); setPrices({}); setItemNotes({}); setNote(''); setIntNote(''); };

  const varQty = (p) => p.variants
    ? p.variants.reduce((s,v)=>s+(cart[`${p.id}:${v.id}`]||0), 0)
    : (cart[p.id]||0);

  const openProductAction = (p, forEdit) => {
    if (forEdit) { setEditProd(p); return; }
    if (p.variants) { setVariantProd(p); return; }
    addPlain(p);
  };

  const holdCurrent = () => {
    if (!list.length) return;
    setHeld(h => [{ id:'h'+Date.now(), name:note||'Pelanggan #'+(held.length+1), items:count, total, time:new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}) }, ...h]);
    clearCart(); setSheet(false); flash('Pesanan ditahan');
  };
  const resumeHeld = (h) => { flash('Melanjutkan: '+h.name); setNote(h.name); setHeld(prev=>prev.filter(x=>x.id!==h.id)); };

  const onNoteChange = (key, val) => setItemNotes(n => ({ ...n, [key]: val }));
  const onOpenPriceEdit = (key) => setPriceEditKey(key);

  const onSearchKey = (e) => {
    if (e.key !== 'Enter') return;
    const q = query.trim(); if (!q) return;
    for (const p of products) {
      if (p.barcode === q) { addPlain(p); flash(p.name+' ditambahkan'); setQuery(''); return; }
      if (p.variants) { const v = p.variants.find(v=>v.barcode===q); if(v){ inc(`${p.id}:${v.id}`); flash(p.name+' — '+v.label+' ditambahkan'); setQuery(''); return; } }
    }
    if (filtered.length === 1) { addPlain(filtered[0]); flash(filtered[0].name+' ditambahkan'); setQuery(''); }
  };

  /* Build transaction object for receipt / history */
  const buildTx = (payment) => {
    const ts = new Date().toLocaleTimeString('id-ID', {hour:'2-digit',minute:'2-digit'});
    const items = list.map(({ key, item, qty }) => ({
      name: item.name, qty, unit: item.unit,
      price: priceOverrides[key] != null ? priceOverrides[key] : item.price,
      note: itemNotes[key] || '', ts,
    }));
    return {
      id: window.POS.nextTxId(),
      customer: note || 'Pelanggan',
      note: note, internalNote,
      items, subtotal, discount, total,
      paid:      payment.paid,
      remaining: Math.max(0, total - payment.paid),
      status:    payment.paid >= total ? 'lunas' : 'belum_lunas',
      payments:  [{ ...payment, ts }],
      time: ts,
    };
  };

  const handlePayDone = (payment) => {
    const tx = buildTx(payment);
    setHistory(h => [tx, ...h]);
    setPayOpen(false);
    clearCart();
    setReceiptTx(tx);
    flash('Transaksi selesai');
  };

  const addToTransaction = (tx) => {
    setNote(tx.customer);
    setIntNote('Tambahan #'+tx.id.toUpperCase());
    flash('Tambahkan item untuk '+tx.customer);
  };

  const priceEditItem = priceEditKey ? byId[priceEditKey] : null;
  const priceEditProduct = priceEditItem
    ? (products.find(p => p.id === priceEditKey || priceEditKey.startsWith(p.id+':')) || {})
    : {};

  const layoutClass = viewMode==='list' ? 'layout-list' : layout==='b' ? 'layout-b' : 'layout-a';

  return (
    <div className={'screen '+layoutClass}>
      <StatusBar />
      {holdOpen && (
        <HoldDropdown held={held} hasCart={list.length>0}
          onHoldCurrent={holdCurrent} onResume={resumeHeld} onClose={()=>setHoldOpen(false)} />
      )}

      {/* Top bar */}
      <div className="topbar">
        <div className="brand-mark"><Icon name="layers" size={18}/></div>
        <div className="search">
          <Icon name="search" size={16}/>
          <input ref={searchRef} value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={onSearchKey}
            placeholder={scan?'Scan barcode…':'Cari produk…'} />
        </div>
        <button className={'icon-btn'+(scan?' active':'')} onClick={()=>{ setScan(s=>!s); searchRef.current?.focus(); }}><Icon name="scan" size={17}/></button>
        <button className={'icon-btn'+(holdOpen?' active':'')} onClick={()=>setHoldOpen(v=>!v)}>
          <Icon name="pause" size={17}/>{held.length>0&&<span className="dot"/>}
        </button>
        <button className="icon-btn" onClick={()=>setTxSheet(true)}><Icon name="clock" size={17}/></button>
        <button className="icon-btn" onClick={onToggleTheme}><Icon name={theme==='dark'?'sun':'moon'} size={17} stroke/></button>
        <div className="cashier-av">R</div>
      </div>

      {/* Category tabs */}
      <div className="cat-tabs">
        {CATS.map(c => <button key={c.id} className={'cat-tab'+(cat===c.id?' on':'')} onClick={()=>setCat(c.id)}>{c.label}</button>)}
      </div>

      {/* Product grid/list */}
      <div className="grid-scroll">
        <div className="grid-head">
          <span className="h">{(CATS.find(c=>c.id===cat)||{}).label}</span>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span className="c">{filtered.length} produk</span>
            <div className="view-toggle">
              <button className={'vt-btn'+(viewMode==='grid'?' on':'')} onClick={()=>setViewMode('grid')}><Icon name="grid" size={14}/></button>
              <button className={'vt-btn'+(viewMode==='list'?' on':'')} onClick={()=>setViewMode('list')}><Icon name="list" size={14}/></button>
            </div>
          </div>
        </div>
        {viewMode==='list' ? (
          <div className="plist">
            {filtered.map(p=><VProductRow key={p.id} p={p} cartQty={varQty(p)} onOpen={openProductAction} onAdd={addPlain} onInc={()=>inc(p.id)} onDec={()=>dec(p.id)}/>)}
          </div>
        ) : (
          <div className="grid">
            {filtered.map(p=><VProductCard key={p.id} p={p} cartQty={varQty(p)} onOpen={openProductAction} onAdd={addPlain} onInc={()=>inc(p.id)} onDec={()=>dec(p.id)}/>)}
          </div>
        )}
        {!filtered.length && <div style={{ textAlign:'center', color:'var(--ink-3)', padding:'50px 20px', fontSize:13.5 }}>Produk "{query}" tidak ditemukan.</div>}
      </div>

      {/* Cart bar */}
      <div className={'cartbar'+(!count?' empty':'')}>
        <div className={'cb-count'+(!count?' empty':'')}>{count||0}</div>
        <div className="cb-info">
          <div className="cb-lbl">{count ? count+' item' : 'Keranjang kosong'}</div>
          <div className={'cb-total'+(!count?' zero':'')}>{rp(total)}</div>
        </div>
        <div className="cb-actions">
          <button className="cb-view" onClick={()=>setSheet(true)} disabled={!count}><Icon name="bag" size={16}/> Lihat</button>
          <button className="cb-pay" disabled={!count} onClick={()=>setPayOpen(true)}>Bayar</button>
        </div>
      </div>

      <BottomNav active="kasir" />

      {/* Overlays */}
      {sheetOpen && (
        <CartSheet list={list} note={note} setNote={setNote}
          internalNote={internalNote} setInternalNote={setIntNote}
          priceOverrides={priceOverrides} itemNotes={itemNotes}
          onOpenPriceEdit={onOpenPriceEdit} onNoteChange={onNoteChange}
          subtotal={subtotal} discount={discount} total={total} count={count}
          onInc={inc} onDec={dec} onClear={clearCart} onHold={holdCurrent}
          onPay={()=>{ setPayOpen(true); setSheet(false); }}
          onClose={()=>setSheet(false)} />
      )}

      {variantProd && <VariantSheet product={variantProd} cart={cart} onInc={inc} onDec={dec} onClose={()=>setVariantProd(null)} />}

      {editProd && <EditProductModal product={editProd} cats={CATS}
        onSave={f=>{ setProducts(ps=>ps.map(p=>p.id===f.id?f:p)); setEditProd(null); flash('Produk diperbarui'); }}
        onClose={()=>setEditProd(null)} />}

      {priceEditKey && priceEditItem && (
        <PriceEditorSheet
          item={priceEditItem}
          altPrices={priceEditProduct.altPrices || []}
          currentPrice={priceOverrides[priceEditKey] != null ? priceOverrides[priceEditKey] : priceEditItem.price}
          onSetPrice={(price) => setPrices(p => ({ ...p, [priceEditKey]: price }))}
          onClose={() => setPriceEditKey(null)} />
      )}

      {payOpen && (
        <PaymentPanel total={total} onClose={()=>setPayOpen(false)} onDone={handlePayDone} />
      )}

      {txSheetOpen && (
        <TransactionSheet history={history} onClose={()=>setTxSheet(false)}
          onAddTo={addToTransaction}
          onLunasi={tx=>flash('#'+tx.id.toUpperCase()+' dicatat lunas')} />
      )}

      {receiptTx && <ReceiptModal tx={receiptTx} onClose={()=>setReceiptTx(null)} />}

      {toast && <div className="toast"><Icon name="check" size={14}/> {toast}</div>}
    </div>
  );
}

Object.assign(window, { CashierApp });
