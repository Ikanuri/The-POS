/* app.jsx — shell: device wrapper, scale, tweaks */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "a",
  "dark": false,
  "accent": ["#c96442", "#d97757"],
  "radius": 14
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const deviceRef = React.useRef(null);

  React.useEffect(() => {
    const r = document.documentElement;
    r.dataset.theme = t.dark ? 'dark' : 'light';
    const a = Array.isArray(t.accent) ? t.accent : [t.accent, t.accent];
    r.style.setProperty('--accent',   a[0]);
    r.style.setProperty('--accent-2', a[1] || a[0]);
    r.style.setProperty('--r-card', t.radius + 'px');
    r.style.setProperty('--r-btn', Math.max(6, Math.round(t.radius * 0.78)) + 'px');
  }, [t.dark, t.accent, t.radius]);

  React.useEffect(() => {
    const fit = () => {
      /* 390×844 device + 28px margin on each side */
      const s = Math.min(
        (window.innerWidth  - 56) / 390,
        (window.innerHeight - 56) / 844
      );
      if (deviceRef.current) deviceRef.current.style.transform = `scale(${Math.min(s, 1)})`;
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  return (
    <>
      <div className="stage">
        <div className="device" ref={deviceRef}>
          <div className="device-island"><div className="cam" /></div>
          <CashierApp
            theme={t.dark ? 'dark' : 'light'}
            onToggleTheme={() => setTweak('dark', !t.dark)}
            layout={t.layout}
          />
        </div>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Tata Letak Produk" />
        <TweakRadio label="Kolom default" value={t.layout}
          options={[
            { value: 'a', label: '2 Kolom' },
            { value: 'b', label: '3 Kolom' },
          ]}
          onChange={(v) => setTweak('layout', v)} />
        <TweakToggle label="Mode gelap" value={t.dark}
          onChange={(v) => setTweak('dark', v)} />

        <TweakSection label="Warna &amp; Bentuk" />
        <TweakColor label="Aksen" value={t.accent}
          options={[
            ['#c96442', '#d97757'],
            ['#b5563a', '#c9694a'],
            ['#5b7c52', '#6e9263'],
            ['#4a6e94', '#5d88b4'],
          ]}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSlider label="Kelengkungan" value={t.radius} min={6} max={24} unit="px"
          onChange={(v) => setTweak('radius', v)} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
